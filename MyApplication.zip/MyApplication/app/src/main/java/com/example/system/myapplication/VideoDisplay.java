package com.example.system.myapplication;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.widget.ImageView;
import android.widget.VideoView;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * @author Emanuel Mellblom
 * Class that handels swowing the video in the GUI
 *
 * info: http://developer.android.com/reference/android/widget/VideoView.html
 */

public class VideoDisplay {

/*
    VideoView videoView = new VideoView();

    String raspberryIP = "192.168.0.102"; //RaspberryPi ip-adress=
    int raspberryPort = 4444;
    wifiConnector raspberryConnector = new wifiConnector(raspberryIP, raspberryPort);



    //Convert byte[] to image
    byte[] blob=c.getBlob("yourcolumnname");
    Bitmap bmp= BitmapFactory.decodeByteArray(blob, 0, blob.length);
    ImageView image=new ImageView(this);
    image.setImageBitmap(bmp);

    //Test 2 byte[] to image
    Bitmap bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
    ImageView newimage = (ImageView) findViewById(R.id.imageView1);


    image.setImageBitmap(bmp);


    Image image = getImageFromByteArray(wifiConnector.recieveData());


    public void showVideo(){
                Image image = getImageFromByteArray(data);
    }

*/

    /*
    public static Image getImageFromByteArray(byte[] byteArray) {
        InputStream is = new ByteArrayInputStream(byteArray);
        try {
            return ImageIO.read(is);
        } catch (IOException ex) {
            System.out.println("Unable to converet byte[] into image.");
            return null;
        }
    }
    */


}
