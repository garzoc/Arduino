package com.example.system.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.io.IOException;


/**
 * @authors Emanuel Mellblom, Tigistu Desta, John Sundling
 * This class handels the joystick control option
 */

public class JoystickControl extends AppCompatActivity {

    private JoystickView joystick;
    private TextView angleTextView;
    private TextView powerTextView;
    //private TextView directionTextView;
    boolean dialogShownFlag = false;
    TextView textView1, textView2, textView3, textView4, textView5;
    RelativeLayout layout_joystick;
    public static boolean obstacleAlertisShown;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_joystick);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Send the control mode to the Arduino
       /* String joystickMode = "j";
        try {
            BtConnection.btOutputStream.write(joystickMode.getBytes());
        } catch (IOException io) {
            AlertBoxes.bluetoothAlert(this);
        } catch (IllegalStateException il) {
            AlertBoxes.bluetoothAlert(this);
        } catch (NullPointerException nu) {
            AlertBoxes.bluetoothAlert(this);
        }*/

        textView1 = (TextView) findViewById(R.id.textView1);
        textView2 = (TextView) findViewById(R.id.textView2);
        textView3 = (TextView) findViewById(R.id.textView3);
        textView4 = (TextView) findViewById(R.id.textView4);
        textView5 = (TextView) findViewById(R.id.textView5);


        layout_joystick = (RelativeLayout) findViewById(R.id.layout_joystick);

        final JoyStickClass js  = new JoyStickClass(getApplicationContext(), layout_joystick, R.drawable.lever);
        //js = new JoyStickClass(getApplicationContext(), layout_joystick, R.drawable.lever);
        js.setStickSize(150, 150);
        js.setLayoutSize(500, 500);
        js.setLayoutAlpha(150);
        js.setStickAlpha(100);
        js.setOffset(90);
        js.setMinimumDistance(50);


        layout_joystick.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1) {
                js.drawStick(arg1);
                if (arg1.getAction() == MotionEvent.ACTION_DOWN
                        || arg1.getAction() == MotionEvent.ACTION_MOVE) {
                    //textView1.setText("X : " + String.valueOf(js.getX()));
                    //textView2.setText("Y : " + String.valueOf(js.getY()));
                    textView3.setText("Angle : " + String.valueOf(Math.round(js.getAngle() % 100)));
                    textView4.setText("Distance : " + String.valueOf(Math.round(js.getDistance() % 100)));

                    try {
                        String send = "c" + Math.round(js.getDistance() % 100) + "|" + Math.round(js.getAngle() % 100);
                        BtConnection.btOutputStream.write(send.getBytes());


                    } catch (IOException io) {
                        if (dialogShownFlag) {
                        } else {
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    } catch (IllegalStateException il) {
                        if (dialogShownFlag) {
                        } else {
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    } catch (NullPointerException nu) {
                        if (dialogShownFlag) {
                        } else {
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    }


                    int direction = js.get8Direction();
                    if (direction == JoyStickClass.STICK_UP) {
                        textView5.setText("Direction : Up");
                    } else if (direction == JoyStickClass.STICK_UPRIGHT) {
                        textView5.setText("Direction : Up Right");
                    } else if (direction == JoyStickClass.STICK_RIGHT) {
                        textView5.setText("Direction : Right");
                    } else if (direction == JoyStickClass.STICK_DOWNRIGHT) {
                        textView5.setText("Direction : Down Right");
                    } else if (direction == JoyStickClass.STICK_DOWN) {
                        textView5.setText("Direction : Down");
                    } else if (direction == JoyStickClass.STICK_DOWNLEFT) {
                        textView5.setText("Direction : Down Left");
                    } else if (direction == JoyStickClass.STICK_LEFT) {
                        textView5.setText("Direction : Left");
                    } else if (direction == JoyStickClass.STICK_UPLEFT) {
                        textView5.setText("Direction : Up Left");
                    } else if (direction == JoyStickClass.STICK_NONE) {
                        textView5.setText("Direction : Center");
                    }
                } else if (arg1.getAction() == MotionEvent.ACTION_UP) {
                    textView3.setText("Angle :");
                    textView4.setText("Speed :");
                    textView5.setText("Direction :");
                }
                return true;
            }
        });




        /*new Thread(new Runnable() {
            @Override
            public void run() {
                while(true){
                    if(js.getDistance() == 0){
                        try {
                            String send = "c0|0";
                            System.out.println("hejsan");
                            BtConnection.btOutputStream.write(send.getBytes());

                        } catch (IOException io) {
                            if(dialogShownFlag){
                            }else{
                                dialogShownFlag = true;
                                //AlertBoxes.bluetoothAlert(JoystickControl.this);
                            }
                        }catch (IllegalStateException il) {
                            if(dialogShownFlag){
                            }else{
                                dialogShownFlag = true;
                                //AlertBoxes.bluetoothAlert(JoystickControl.this);
                            }
                        } catch (NullPointerException nu) {
                            if(dialogShownFlag){
                            }else{
                                dialogShownFlag = true;
                                //AlertBoxes.bluetoothAlert(JoystickControl.this);
                            }
                        }
                    }*/
                    //textView3.setText("Angle : " + String.valueOf(Math.round(js.getAngle()%100)));
                    //textView4.setText("Distance : " + String.valueOf(Math.round(js.getDistance() % 100)));
                    /*runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView3.setText("Angle : " + String.valueOf(Math.round(js.getAngle()%100)));
                            textView4.setText("Distance : " + String.valueOf(Math.round(js.getDistance() % 100)));
                        }
                    });*/
    }

    public void readSensorInput(){
        try {
            obstacleAlertisShown = false;
            //char in = (char)BtConnection.btInputStream.read();
            //if (in == '1') {
            if(BtConnection.btInputStream.read() == 49){
                System.out.println("Obstacle detected");
                System.out.println("" + BtConnection.btInputStream.read());
                if(!obstacleAlertisShown){
                    AlertBoxes.obstacleDetected(this);
                    obstacleAlertisShown = true;
                }
            }else{}
        }catch(IOException io){
            //System.out.println("Error reading input");
            AlertBoxes.bluetoothAlert(this);
        }catch (IllegalStateException il){
            AlertBoxes.bluetoothAlert(this);
        }catch(NullPointerException nu){
            AlertBoxes.bluetoothAlert(this);
        }
    }


            //}
       // }).start();
    //}

        //angleTextView = (TextView) findViewById(R.id.angleTextView);
        //powerTextView = (TextView) findViewById(R.id.powerTextView);
        //directionTextView = (TextView) findViewById(R.id.directionTextView);
        //Referencing also other views
       /* joystick = (JoystickView) findViewById(R.id.joystickView);

        //Event listener that always returns the variation of the angle in degrees, motion power in percentage and direction of movement
        joystick.setOnJoystickMoveListener(new JoystickView.OnJoystickMoveListener() {

            @Override
            public void onValueChanged(int angle, int power, int direction) {
                // TODO Auto-generated method stub
                angleTextView.setText(" " + String.valueOf(angle) + "°");
                powerTextView.setText(" " + String.valueOf(power) + "%");

                //New test to send to Arduino
                String theangle = String.valueOf(angle); //String theangle = "a" + "\n" + String.valueOf(angle);
                String thePower = String.valueOf(power); //String thePower = "p" + "\n" + String.valueOf(power);
                    try {
                            BtConnection.btOutputStream.write(theangle.getBytes());
                            BtConnection.btOutputStream.write(thePower.getBytes());
                    } catch (IOException io) {
                        if(dialogShownFlag){
                            return;
                        }else{
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    } catch (IllegalStateException il) {
                        if(dialogShownFlag){
                            return;
                        }else{
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    } catch (NullPointerException nu) {
                        if(dialogShownFlag){
                            return;
                        }else{
                            dialogShownFlag = true;
                            AlertBoxes.bluetoothAlert(JoystickControl.this);
                        }
                    }
            }
        }, JoystickView.DEFAULT_LOOP_INTERVAL);
    }*/


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.buttonmode) {
            Intent intent = new Intent(this, buttonControl.class);
            startActivity(intent);
            return true;
        }
        if(id == R.id.connectToBluetooth){
            BtConnection.setBluetoothData();
            BtConnection.blueTooth();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
