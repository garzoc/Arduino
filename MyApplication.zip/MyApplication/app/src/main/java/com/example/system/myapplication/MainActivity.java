package com.example.system.myapplication;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.bluetooth.BluetoothAdapter;
import android.support.v7.widget.Toolbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;

import java.io.IOException;

/**
 * Main class for MARS SmartCar
 * @author  Emanuel Mellblom
 */

public class MainActivity extends AppCompatActivity {

    private final int REQUEST_ENABLE_BT = 12;
    String raspberryIP = "172.20.10.5"; //RaspberryPi ip-adress=
    int raspberryPort = 6666;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (BtConnection.blueTooth()) {
            Intent enableBtIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }
    }

    //Test wificonnection
    public void connectWifi(View view){

        ImageView images = (ImageView) findViewById(R.id.images);
        wifiConnector rasp = new wifiConnector(raspberryIP, raspberryPort, images);
            rasp.setIP(raspberryIP);
            rasp.connect(raspberryIP, raspberryPort);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.buttonmode) {
            Intent intent = new Intent(this, buttonControl.class);
            startActivity(intent);

            //test write mode to serial
            try {
                String buttonMode = "buttonMode";
                BtConnection.btOutputStream.write(buttonMode.getBytes());

            } catch (IOException io) {
                //System.out.println("Error reading input");
                AlertBoxes.bluetoothAlert(this);
            } catch (IllegalStateException il) {
                AlertBoxes.bluetoothAlert(this);
            } catch (NullPointerException nu) {
                AlertBoxes.bluetoothAlert(this);
            }
            //End of write to serial test

            return true;
        }
        if(id == R.id.action_jo){
            Intent intent = new Intent(this, JoystickControl.class);
            startActivity(intent);

            //Test write joystick mode to serial
            try {
                String joystickMode = "joystickMode";
                BtConnection.btOutputStream.write(joystickMode.getBytes());
            } catch (IOException io) {
                //System.out.println("Error reading input");
                AlertBoxes.bluetoothAlert(this);
            } catch (IllegalStateException il) {
                AlertBoxes.bluetoothAlert(this);
            } catch (NullPointerException nu) {
                AlertBoxes.bluetoothAlert(this);
            }
            //End of test joystick
            return true;
        }
        if(id == R.id.connectToBluetooth){
            BtConnection.setBluetoothData();
            BtConnection.blueTooth();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}

